var temporizador; // se declara la variable del temporizador

// posicion del jugador 
var miposx = 225; // posicion x,y dle jugador
var miposy = 450;
var movimientopersonaje = ""; // se inicia la variable de la direcci�n de movimiento usada en movimientoJugador()

//balas

var balaposx = new Array(); //declaramos los array de las posiciones de las balas
var balaposy = new Array();
var balasmax = 0; // ponemos a 0 el contador de balas disparadas;
var balasmin = 0; //contador de balas dentro del terreno de juego

var balaviva = new Array(); // variable bool para activar las balas

var balastiempo = 30; // contador de tiempo para el lanzamiento de balas

// balas enemigos

var balaenemigoposx = new Array(); //declaramos los array de las posiciones de las balas
var balaenemigoposy = new Array();
var balaenemigomax = 0; // ponemos a 0 el contador de balas disparadas;
var balaenemigomin = 0; //contador de balas dentro del terreno de juego

var balaenemigoviva = new Array(); // variable bool para activar las balas
var balasenemigotiempo = 0; // contador de tiempo para el lanzamiento de balas

// enemigos

 
var enemigoposx = new Array(); // almacenan la posici�n x ,y de cada uno de los enemigos
enemigoposx[0] = 25;
enemigoposx[1] = 75;
enemigoposx[2] = 125;
enemigoposx[3] = 175;
enemigoposx[4] = 225;
enemigoposx[5] = 275;

var enemigoposy = 25; // y com�n ya que se mueven en bloque
var enemigos = 5; // n�mero de enemigos con los que se inicia el nivel 
var hasganado = (enemigos+1); // contador para saber cuando se han eliminado a todos los enemigos

var enemigovivo = new Array(); //almacena si el enemigo est� vivo o no
for(var i = 0;i<=enemigos;i++){ //inicializa todos en true
	enemigovivo[i] = true;
}
var movimientoenemigos = "derecha";  // se inicia la variable de la direcci�n de movimiento usada en movimientoEnemigo()

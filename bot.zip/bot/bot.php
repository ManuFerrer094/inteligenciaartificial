<?php 

session_start();
if(!isset($_SESSION['id'])){
	$_SESSION['id'] = 0;
}
 ?>
<html>
	<head>
	<meta charset="utf-8"> 
		<script type="text/javascript" src="jquery-1.7.2.min.js">
		</script>
		<script type="text/javascript">
			var lognaniza;
			$(document).ready(inicio)
			function inicio(){
				
				principal();
			}
			function principal(){
				longaniza = "";
				
				
					
					
				
				$(".blue-box-wrap").each(function(){
					longaniza += ";"+$("#ch_lblVerb").text()+","
					longaniza += $(this).find("p").text()+","
					$(this).find("li").each(function(){
						longaniza += $(this).find(".auxgraytxt").text()+"";
						longaniza += $(this).find(".verbtxt").text()+",";
					})
				})
				console.log(longaniza)
				$("#ajax").load("http://localhost/bot/escribe.php?mensaje="+encodeURI(longaniza))
				random = Math.round(Math.random()*15000+15000)
				setTimeout("repite()",random );
			}
			function repite(){
				window.location.href=window.location.href
			}
		</script>
		<style>
			#contenido{
				width:1000px;
				height:1000px;
				border:2px solid black;
				overflow:hidden;
			}
		</style>
	</head>
	<body>
		<div id="receptordeinformacion">
		Aqui recibiré la informacion
		</div>
		<div id="chivato"></div>
		<div id="contenido">
			<?php 
			
			//sleep(2);
			$mysqli = new mysqli("localhost", "lenguajenatural", "lenguajenatural", "lenguajenatural");
			$consulta = "SELECT * FROM palabras WHERE  tipo LIKE '%RED%' LIMIT 1 OFFSET ".$_SESSION['id']."";
			$resultado = $mysqli->query($consulta);  
			 while ($fila = $resultado->fetch_assoc()) {
				echo file_get_contents("http://conjugador.reverso.net/conjugacion-espanol-verbo-".$fila['palabra'].".html");
			}

			$_SESSION['id']++;
			?>
		</div>
		<div id="ajax"></div>
	</body>
</html>

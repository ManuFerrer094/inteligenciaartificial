<?php
header('Content-type: text/html; charset=utf-8');
$myfile = fopen("verbos.txt", "a") or die("Unable to open file!");

$txt = $_GET['mensaje']."\n";
fwrite($myfile, $txt);
fclose($myfile);
echo "ok";
?>

